package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView textViewSaldo;
    private EditText editTextMonto;
    private double saldo = 0.00;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewSaldo = findViewById(R.id.textViewSaldo);
        editTextMonto = findViewById(R.id.editTextMonto);

        // Recuperar el saldo anterior si está disponible
        if (savedInstanceState != null) {
            saldo = savedInstanceState.getDouble("saldo");
            actualizarSaldo();
        }

        Button btnConsignar = findViewById(R.id.btnConsignar);
        Button btnRetirar = findViewById(R.id.btnRetirar);

        btnConsignar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                consignar();
            }
        });

        btnRetirar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retirar();
            }
        });
    }

    private void consignar() {
        double monto = obtenerMontoIngresado();
        saldo += monto;
        actualizarSaldo();
        Toast.makeText(this, "Consignación exitosa", Toast.LENGTH_SHORT).show();
    }

    private void retirar() {
        double monto = obtenerMontoIngresado();
        if (monto > saldo) {
            Toast.makeText(this, "No hay suficiente saldo para retirar", Toast.LENGTH_SHORT).show();
        } else {
            saldo -= monto;
            actualizarSaldo();
            Toast.makeText(this, "Retiro exitoso", Toast.LENGTH_SHORT).show();
        }
    }

    private double obtenerMontoIngresado() {
        String montoStr = editTextMonto.getText().toString();
        if (!montoStr.isEmpty()) {
            return Double.parseDouble(montoStr);
        }
        return 0.00;
    }

    private void actualizarSaldo() {
        textViewSaldo.setText("Saldo Actual: $" + saldo);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putDouble("saldo", saldo);
        super.onSaveInstanceState(outState);
    }
}
